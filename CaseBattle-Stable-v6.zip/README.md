# CaseBattle Build v5

Android demo/simulator project built with Kotlin + Jetpack Compose.

## Build layout

This ZIP contains the Android project directly at its root. Build scripts use Gradle Groovy DSL (`settings.gradle`, `build.gradle`, `app/build.gradle`) to keep CI configuration simple and avoid Kotlin DSL script compilation issues.

Recommended CI stack:
- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21
- Gradle 8.13
- JDK 17
- compileSdk / targetSdk 36
- Compose BOM 2026.08.00

## Demo admin

Username: `admin`
Password: `caseforge`

Admin controls only virtual/demo credits and simulator odds. No real-money deposits, withdrawals, Steam trades, or cash-out are implemented.


## v6 build fix

Compose BOM is pinned to `2026.06.01` (Compose 1.11 generation) because Compose BOM `2026.08.00` brings Compose 1.12, which requires compileSdk 37 and AGP 9.x. This project intentionally remains on compileSdk 36 + AGP 8.13.2 for a conservative CI-compatible build.
