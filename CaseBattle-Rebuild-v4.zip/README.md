# CaseBattle Rebuild v4

Android demo/simulator project built with Kotlin + Jetpack Compose.

## GitHub Actions layout

Upload `CaseBattle-Rebuild-v4.zip` to the repository root. Put only `android-ci-v4.yml` in `.github/workflows/`. Delete older Android workflow files to avoid duplicate failing runs.

The ZIP now contains the Android project directly at its root (`settings.gradle.kts`, `build.gradle.kts`, `app/`). The workflow extracts it into `_android_project` and builds `:app:assembleDebug` with Gradle 8.13 / JDK 17.

## Demo admin

Username: `admin`
Password: `caseforge`

The admin controls only virtual/demo credits and simulator odds. No real-money deposits, withdrawals, Steam trading or cash-out are implemented.

## Build stack

- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21
- Gradle 8.13
- JDK 17
- compileSdk / targetSdk 36
- Compose BOM 2026.08.00
- Activity Compose 1.13.0

## Local build

Open this directory in Android Studio and sync Gradle. If you prefer command-line builds, use an installed Gradle 8.13 or generate a Gradle wrapper from Android Studio/Gradle.
