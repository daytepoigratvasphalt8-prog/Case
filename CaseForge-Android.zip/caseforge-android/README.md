# CaseForge Android

Android-приложение на Kotlin + Jetpack Compose в формате case-opening / case-battle simulator. UI сделан оригинальным, а структура механик ориентирована на современные CS2 case-opening сервисы.

## Что уже реализовано

- каталог кейсов и карточки кейсов;
- реальные `market_hash_name` CS2-предметов;
- получение актуального `lowest_price` в USD с Steam Community Market;
- загрузка реальных изображений скинов со страницы Steam Market;
- отображение содержимого кейса и вероятностей выпадения;
- анимированное открытие кейса;
- виртуальный инвентарь;
- продажа предмета за demo credits;
- локальная 1v1 Case Battle против бота;
- Upgrade x2/x3/x5;
- Contracts из 3–5 предметов;
- резервные цены, если Steam временно ограничивает запросы;
- полностью Compose UI, адаптированный под телефон.

## Важное ограничение

Это simulator/demo-проект. В нём намеренно нет платежей, пополнения/вывода денег, cash-out, выдачи реальных Steam-предметов, Steam trade bot, ставок на реальные деньги или иных real-money gambling-функций. Рыночные цены используются только как информационная оценка виртуальных предметов.

## Источник цен

`SteamMarketClient` использует публично доступный endpoint Steam Community Market `priceoverview` и страницу listing. Steam не документирует `priceoverview` как стабильный официальный Market API, поэтому для production рекомендуется вынести цены и изображения на свой backend и подключить лицензированного поставщика market-data. Репозиторий клиента изолирован именно для такой замены.

## Технологии

- Kotlin 2.3.21
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- compileSdk / targetSdk 36
- minSdk 23
- Jetpack Compose BOM 2026.08.00
- Activity Compose 1.13.0
- kotlinx-coroutines-android 1.11.0
- JDK 17

## Запуск в Android Studio

1. Распакуйте проект или клонируйте его в GitHub.
2. Android Studio → **Open** → выберите корневую папку `caseforge-android`.
3. Выберите JDK 17 для Gradle.
4. Выполните Gradle Sync.
5. Запустите `app` на Android 6.0+ (API 23+) или эмуляторе.

В проекте зафиксирован `gradle/wrapper/gradle-wrapper.properties` для Gradle 8.13. Если вы запускаете сборку только из CLI и в репозитории ещё нет wrapper JAR/scripts, один раз выполните `gradle wrapper --gradle-version 8.13` установленным Gradle, после чего закоммитьте сгенерированные `gradlew`, `gradlew.bat` и `gradle/wrapper/gradle-wrapper.jar`.

## Структура

- `MainActivity.kt` — точка входа;
- `ui/CaseForgeApp.kt` — весь Compose UI и demo flow;
- `model/Models.kt` — модели предметов, кейсов, инвентаря и навигации;
- `data/DemoCatalog.kt` — набор скинов, кейсов, веса выпадения;
- `data/SteamMarketClient.kt` — live price/image lookup и кэш.

## Проверка данных

Встроенные кейсы имеют суммарный вес выпадения 100%. Модель каталога отдельно компилируется обычным Kotlin compiler и тестируется серией roll-вызовов.

## Production-развитие

Для полноценного многопользовательского продукта клиентскую случайность нельзя считать доверенной. Battle/opening/upgrade/contract результаты должны рассчитываться сервером, подписываться и сохраняться в БД. Также нужны аккаунты, backend API, WebSocket/Realtime для PvP, rate limiting, telemetry и отдельный market-data cache.
