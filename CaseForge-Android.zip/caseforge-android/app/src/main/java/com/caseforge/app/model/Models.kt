package com.caseforge.app.model

enum class Rarity(val label: String) {
    MIL_SPEC("Mil-Spec"),
    RESTRICTED("Restricted"),
    CLASSIFIED("Classified"),
    COVERT("Covert"),
    EXTRAORDINARY("Extraordinary")
}

data class Skin(
    val id: String,
    val marketHashName: String,
    val weapon: String,
    val finish: String,
    val wear: String,
    val rarity: Rarity,
    val fallbackUsd: Double,
)

data class CaseDrop(
    val skin: Skin,
    val weight: Int,
)

data class GameCase(
    val id: String,
    val title: String,
    val subtitle: String,
    val costCredits: Int,
    val accent: Long,
    val drops: List<CaseDrop>,
)

data class OwnedSkin(
    val inventoryId: Long,
    val skin: Skin,
)

data class MarketInfo(
    val lowestPriceLabel: String? = null,
    val lowestPriceUsd: Double? = null,
    val imageUrl: String? = null,
    val isLive: Boolean = false,
)

data class BattleResult(
    val player: Skin,
    val opponent: Skin,
    val won: Boolean,
)

sealed interface Screen {
    data object Home : Screen
    data class CaseDetails(val caseId: String) : Screen
    data class Opening(val caseId: String) : Screen
    data object Battles : Screen
    data object Upgrade : Screen
    data object Contract : Screen
    data object Inventory : Screen
}
