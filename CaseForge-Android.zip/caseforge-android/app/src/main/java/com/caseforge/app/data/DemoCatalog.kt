package com.caseforge.app.data

import com.caseforge.app.model.CaseDrop
import com.caseforge.app.model.GameCase
import com.caseforge.app.model.Rarity
import com.caseforge.app.model.Skin
import kotlin.random.Random

object DemoCatalog {
    val skins = listOf(
        Skin("ak-redline-ft", "AK-47 | Redline (Field-Tested)", "AK-47", "Redline", "Field-Tested", Rarity.CLASSIFIED, 24.0),
        Skin("awp-asiimov-ft", "AWP | Asiimov (Field-Tested)", "AWP", "Asiimov", "Field-Tested", Rarity.COVERT, 105.0),
        Skin("m4-printstream-ft", "M4A1-S | Printstream (Field-Tested)", "M4A1-S", "Printstream", "Field-Tested", Rarity.COVERT, 185.0),
        Skin("deagle-printstream-ft", "Desert Eagle | Printstream (Field-Tested)", "Desert Eagle", "Printstream", "Field-Tested", Rarity.COVERT, 42.0),
        Skin("usp-kill-confirmed-ft", "USP-S | Kill Confirmed (Field-Tested)", "USP-S", "Kill Confirmed", "Field-Tested", Rarity.COVERT, 60.0),
        Skin("m4-emperor-ft", "M4A4 | The Emperor (Field-Tested)", "M4A4", "The Emperor", "Field-Tested", Rarity.COVERT, 36.0),
        Skin("ak-neon-rider-ft", "AK-47 | Neon Rider (Field-Tested)", "AK-47", "Neon Rider", "Field-Tested", Rarity.COVERT, 42.0),
        Skin("awp-neo-noir-ft", "AWP | Neo-Noir (Field-Tested)", "AWP", "Neo-Noir", "Field-Tested", Rarity.COVERT, 28.0),
        Skin("ak-vulcan-ft", "AK-47 | Vulcan (Field-Tested)", "AK-47", "Vulcan", "Field-Tested", Rarity.COVERT, 285.0),
        Skin("m4-hyperbeast-ft", "M4A1-S | Hyper Beast (Field-Tested)", "M4A1-S", "Hyper Beast", "Field-Tested", Rarity.COVERT, 46.0),
        Skin("awp-hyperbeast-ft", "AWP | Hyper Beast (Field-Tested)", "AWP", "Hyper Beast", "Field-Tested", Rarity.COVERT, 32.0),
        Skin("deagle-blaze-fn", "Desert Eagle | Blaze (Factory New)", "Desert Eagle", "Blaze", "Factory New", Rarity.RESTRICTED, 560.0),
        Skin("glock-vogue-ft", "Glock-18 | Vogue (Field-Tested)", "Glock-18", "Vogue", "Field-Tested", Rarity.CLASSIFIED, 8.5),
        Skin("usp-printstream-ft", "USP-S | Printstream (Field-Tested)", "USP-S", "Printstream", "Field-Tested", Rarity.COVERT, 55.0),
        Skin("ak-bloodsport-ft", "AK-47 | Bloodsport (Field-Tested)", "AK-47", "Bloodsport", "Field-Tested", Rarity.COVERT, 94.0),
        Skin("m4-temukau-ft", "M4A4 | Temukau (Field-Tested)", "M4A4", "Temukau", "Field-Tested", Rarity.COVERT, 13.5),
        Skin("awp-lightning-fn", "AWP | Lightning Strike (Factory New)", "AWP", "Lightning Strike", "Factory New", Rarity.COVERT, 720.0),
        Skin("ak-casehardened-ft", "AK-47 | Case Hardened (Field-Tested)", "AK-47", "Case Hardened", "Field-Tested", Rarity.CLASSIFIED, 270.0),
        Skin("karambit-doppler-fn", "★ Karambit | Doppler (Factory New)", "Karambit", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 1900.0),
        Skin("butterfly-doppler-fn", "★ Butterfly Knife | Doppler (Factory New)", "Butterfly Knife", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 3400.0),
        Skin("m9-doppler-fn", "★ M9 Bayonet | Doppler (Factory New)", "M9 Bayonet", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 1750.0),
    )

    private fun s(id: String) = skins.first { it.id == id }

    val cases = listOf(
        GameCase(
            id = "starter",
            title = "Starter Drop",
            subtitle = "Cheap rifles & pistols",
            costCredits = 220,
            accent = 0xFF8CFF5B,
            drops = listOf(
                CaseDrop(s("glock-vogue-ft"), 34),
                CaseDrop(s("m4-temukau-ft"), 25),
                CaseDrop(s("ak-redline-ft"), 19),
                CaseDrop(s("awp-neo-noir-ft"), 12),
                CaseDrop(s("deagle-printstream-ft"), 7),
                CaseDrop(s("usp-kill-confirmed-ft"), 3),
            )
        ),
        GameCase(
            id = "rifle-rush",
            title = "Rifle Rush",
            subtitle = "AK & M4 focused",
            costCredits = 620,
            accent = 0xFF44D7FF,
            drops = listOf(
                CaseDrop(s("m4-temukau-ft"), 28),
                CaseDrop(s("ak-redline-ft"), 24),
                CaseDrop(s("m4-emperor-ft"), 18),
                CaseDrop(s("ak-neon-rider-ft"), 13),
                CaseDrop(s("m4-hyperbeast-ft"), 9),
                CaseDrop(s("ak-bloodsport-ft"), 5),
                CaseDrop(s("ak-vulcan-ft"), 3),
            )
        ),
        GameCase(
            id = "awp-vault",
            title = "AWP Vault",
            subtitle = "Sniper-only pool",
            costCredits = 900,
            accent = 0xFF9F7BFF,
            drops = listOf(
                CaseDrop(s("awp-neo-noir-ft"), 38),
                CaseDrop(s("awp-hyperbeast-ft"), 29),
                CaseDrop(s("awp-asiimov-ft"), 22),
                CaseDrop(s("awp-lightning-fn"), 11),
            )
        ),
        GameCase(
            id = "red-tier",
            title = "Red Tier",
            subtitle = "Covert-heavy case",
            costCredits = 1_650,
            accent = 0xFFFF5266,
            drops = listOf(
                CaseDrop(s("deagle-printstream-ft"), 22),
                CaseDrop(s("m4-emperor-ft"), 19),
                CaseDrop(s("ak-neon-rider-ft"), 17),
                CaseDrop(s("usp-printstream-ft"), 15),
                CaseDrop(s("ak-bloodsport-ft"), 11),
                CaseDrop(s("awp-asiimov-ft"), 8),
                CaseDrop(s("m4-printstream-ft"), 5),
                CaseDrop(s("ak-vulcan-ft"), 3),
            )
        ),
        GameCase(
            id = "collector",
            title = "Collector",
            subtitle = "Rare market pieces",
            costCredits = 3_900,
            accent = 0xFFFFC857,
            drops = listOf(
                CaseDrop(s("ak-bloodsport-ft"), 30),
                CaseDrop(s("m4-printstream-ft"), 24),
                CaseDrop(s("ak-casehardened-ft"), 19),
                CaseDrop(s("deagle-blaze-fn"), 15),
                CaseDrop(s("awp-lightning-fn"), 9),
                CaseDrop(s("m9-doppler-fn"), 2),
                CaseDrop(s("karambit-doppler-fn"), 1),
            )
        ),
        GameCase(
            id = "knife-dream",
            title = "Knife Dream",
            subtitle = "High variance demo case",
            costCredits = 9_500,
            accent = 0xFFFF8A3D,
            drops = listOf(
                CaseDrop(s("ak-vulcan-ft"), 36),
                CaseDrop(s("deagle-blaze-fn"), 28),
                CaseDrop(s("awp-lightning-fn"), 18),
                CaseDrop(s("m9-doppler-fn"), 9),
                CaseDrop(s("karambit-doppler-fn"), 6),
                CaseDrop(s("butterfly-doppler-fn"), 3),
            )
        )
    )

    fun case(id: String): GameCase = cases.first { it.id == id }

    fun roll(gameCase: GameCase, random: Random = Random.Default): Skin {
        val total = gameCase.drops.sumOf { it.weight }
        var cursor = random.nextInt(total)
        for (drop in gameCase.drops) {
            if (cursor < drop.weight) return drop.skin
            cursor -= drop.weight
        }
        return gameCase.drops.last().skin
    }

    fun closestByFallbackPrice(targetUsd: Double): Skin = skins.minBy { kotlin.math.abs(it.fallbackUsd - targetUsd) }
}
