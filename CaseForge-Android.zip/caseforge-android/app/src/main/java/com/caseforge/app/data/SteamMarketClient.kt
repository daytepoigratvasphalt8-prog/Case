package com.caseforge.app.data

import com.caseforge.app.model.MarketInfo
import com.caseforge.app.model.Skin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap

/**
 * Lightweight demo client for public Steam Community Market pages.
 * Steam does not document priceoverview as a supported public API, so production apps
 * should replace this class with a licensed/stable price-data provider on a backend.
 */
object SteamMarketClient {
    private val cache = ConcurrentHashMap<String, MarketInfo>()

    fun cached(marketHashName: String): MarketInfo? = cache[marketHashName]

    suspend fun load(skin: Skin): MarketInfo = withContext(Dispatchers.IO) {
        cache[skin.marketHashName]?.let { return@withContext it }

        val price = runCatching { fetchPrice(skin.marketHashName) }.getOrNull()
        val image = runCatching { fetchImage(skin.marketHashName) }.getOrNull()
        val info = MarketInfo(
            lowestPriceLabel = price?.first,
            lowestPriceUsd = price?.second,
            imageUrl = image,
            isLive = price != null,
        )
        cache[skin.marketHashName] = info
        info
    }

    private fun fetchPrice(name: String): Pair<String, Double?>? {
        val encoded = URLEncoder.encode(name, StandardCharsets.UTF_8.toString())
        val url = URL("https://steamcommunity.com/market/priceoverview/?appid=730&currency=1&market_hash_name=$encoded")
        val text = get(url) ?: return null
        val json = JSONObject(text)
        if (!json.optBoolean("success", false)) return null
        val label = json.optString("lowest_price").takeIf { it.isNotBlank() } ?: return null
        return label to parseUsd(label)
    }

    private fun fetchImage(name: String): String? {
        val encoded = URLEncoder.encode(name, StandardCharsets.UTF_8.toString()).replace("+", "%20")
        val html = get(URL("https://steamcommunity.com/market/listings/730/$encoded")) ?: return null
        val patterns = listOf(
            Regex("id=\\\"market_listing_largeimage\\\"[^>]*src=\\\"([^\\\"]+)\\\"", RegexOption.IGNORE_CASE),
            Regex("src=\\\"([^\\\"]+)\\\"[^>]*id=\\\"market_listing_largeimage\\\"", RegexOption.IGNORE_CASE),
        )
        return patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.getOrNull(1) }
            ?.replace("&amp;", "&")
    }

    private fun get(url: URL): String? {
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 7_000
            readTimeout = 7_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 CaseForge/0.1 Android")
            setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        }
        return try {
            if (connection.responseCode !in 200..299) null
            else connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseUsd(label: String): Double? {
        val normalized = label.replace(Regex("[^0-9.,]"), "")
        if (normalized.isBlank()) return null
        val dot = normalized.lastIndexOf('.')
        val comma = normalized.lastIndexOf(',')
        return when {
            dot >= 0 && comma >= 0 -> {
                val decimal = maxOf(dot, comma)
                val clean = normalized.filterIndexed { index, c -> c.isDigit() || index == decimal }
                    .replace(',', '.')
                clean.toDoubleOrNull()
            }
            comma >= 0 -> normalized.replace(',', '.').toDoubleOrNull()
            else -> normalized.toDoubleOrNull()
        }
    }
}
