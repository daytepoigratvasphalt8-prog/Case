# CaseForge Android

Android-приложение на Kotlin + Jetpack Compose в формате CS2 case-opening / case-battle simulator. Интерфейс оригинальный, а набор механик ориентирован на современные case-opening приложения.

## Версия 0.2.0

Обновление расширяет каталог и добавляет полноценный локальный demo-admin режим.

### Что реализовано

- 18 кейсов вместо 6: от `Pocket Change` до `Dragon Vault`;
- 57 реальных CS2 `market_hash_name` в каталоге;
- получение текущего `lowest_price` в USD с Steam Community Market, когда endpoint доступен;
- загрузка изображений предметов со Steam Market listing;
- fallback-цены, чтобы приложение продолжало работать при rate-limit/ошибке Steam;
- индивидуальная цена каждого кейса в demo credits;
- отдельный процент `Profit` / `Loss` для каждого кейса;
- выбор результата в два этапа: сначала profit/loss bucket, затем конкретный предмет по внутренним весам;
- отображение эффективной вероятности предмета внутри текущей настройки profit/loss;
- анимированное открытие кейса;
- виртуальный инвентарь;
- продажа предметов за demo credits;
- локальная 1v1 Case Battle против бота;
- Upgrade x2/x3/x5;
- Contracts из 3–5 предметов;
- локальная admin-панель;
- сохранение изменённых процентов кейсов через `SharedPreferences`;
- счётчик фактических profit/loss результатов по каждому кейсу;
- ориентировочный RTP по fallback-ценам;
- GitHub Actions workflow `android.yml`.

## Demo Admin

Открыть админку можно кнопкой `ADM` в верхней панели.

Локальные demo-данные:

- Username: `admin`
- Password: `caseforge`

В admin panel можно:

- менять `Profit chance` каждого кейса от 0% до 100%;
- автоматически получать `Loss chance = 100% - Profit chance`;
- менять шанс шагами ±1, ±5, ±10;
- применять быстрые пресеты 10 / 25 / 35 / 50 / 75%;
- пополнять виртуальный баланс на 10K / 100K CR или выставлять 1M CR;
- возвращать все odds к значениям по умолчанию;
- сбрасывать статистику открытий;
- видеть настроенный Profit/Loss, число фактических открытий и observed profit rate;
- видеть ориентировочный RTP кейса.

Admin credentials и odds находятся на клиенте только потому, что это локальный simulator. Для production нельзя хранить реальные административные секреты, RNG или payout-настройки внутри APK.

## Как работают Profit / Loss odds

Для каждого кейса задан `defaultProfitChancePercent`.

При открытии:

1. RNG выбирает категорию результата по `Profit chance`.
2. `Profit` означает, что reference/cached стоимость предмета не ниже стоимости кейса.
3. `Loss` означает, что стоимость предмета ниже стоимости кейса.
4. После выбора категории конкретный предмет выбирается по `weight` только среди предметов этой категории.

То есть настройка `30% Profit / 70% Loss` влияет непосредственно на выдачу, а не является декоративной цифрой.

Все 18 кейсов проверены так, чтобы иметь и profit-, и loss-пул. Веса предметов внутри каждого кейса суммируются до 100. Monte Carlo-проверка на 20 000 открытий каждого кейса показывает фактическую частоту profit близко к заданной.

Default odds подобраны так, чтобы ориентировочный RTP большинства кейсов по fallback-ценам находился примерно около 90%. Через admin panel эти значения можно свободно менять в simulator-режиме.

## Важное ограничение

Это simulator/demo-проект. В нём намеренно нет платежей, пополнения/вывода реальных денег, cash-out, выдачи Steam-предметов, Steam trade bot и ставок на реальные деньги. Рыночные цены используются как информационная оценка виртуальных предметов.

## Источник цен

`SteamMarketClient` использует публично доступный Steam Community Market `priceoverview` и HTML listing для картинки. Steam не документирует `priceoverview` как гарантированный стабильный Market API, поэтому для production market-data следует вынести на backend и использовать стабильного поставщика данных.

Архитектурно сетевой код изолирован в `data/SteamMarketClient.kt`, поэтому источник цен можно заменить, не переписывая основной UI.

## Технологии

- Kotlin 2.3.21
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- compileSdk / targetSdk 36
- minSdk 23
- Jetpack Compose BOM 2026.08.00
- Activity Compose 1.13.0
- kotlinx-coroutines-android 1.11.0
- JDK 17

## Запуск в Android Studio

1. Распакуйте `CaseForge-Android.zip` или загрузите содержимое в GitHub.
2. Android Studio → **Open** → выберите папку `caseforge-android`.
3. Выберите JDK 17 для Gradle.
4. Выполните Gradle Sync.
5. Запустите модуль `app` на Android 6.0+ или эмуляторе.

`android.yml` использует установленный через GitHub Actions Gradle 8.13, поэтому наличие локального `gradlew` для CI не требуется.

## Структура проекта

- `MainActivity.kt` — точка входа;
- `ui/CaseForgeApp.kt` — Compose UI, состояние приложения, admin login/admin panel и demo flow;
- `model/Models.kt` — модели предметов, кейсов, статистики и навигации;
- `data/DemoCatalog.kt` — 57 предметов, 18 кейсов, веса, profit/loss RNG и RTP helper;
- `data/SteamMarketClient.kt` — live price/image lookup и cache;
- `android.yml` — копия CI workflow в корне;
- `.github/workflows/android.yml` — workflow, который GitHub запускает автоматически.

## Проверка данных

Перед упаковкой версии 0.2.0 отдельно проверено:

- `Models.kt + DemoCatalog.kt` компилируются обычным Kotlin compiler;
- 57 уникальных записей предметов и 18 кейсов читаются каталогом;
- веса каждого кейса = 100;
- у каждого кейса есть и profit-, и loss-пул;
- выполнено 20 000 тестовых roll-вызовов на кейс и фактический profit rate соответствует настройке с обычной статистической погрешностью.

Полную Android APK-сборку в текущем окружении без Android SDK не выполняли; для этого предназначен included GitHub Actions workflow либо Android Studio.
