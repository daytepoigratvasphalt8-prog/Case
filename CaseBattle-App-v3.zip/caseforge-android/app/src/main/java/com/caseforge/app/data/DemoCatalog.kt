package com.caseforge.app.data

import com.caseforge.app.model.CaseDrop
import com.caseforge.app.model.GameCase
import com.caseforge.app.model.Rarity
import com.caseforge.app.model.Skin
import kotlin.math.abs
import kotlin.random.Random

object DemoCatalog {
    val skins = listOf(
        Skin("p250-valence-ft", "P250 | Valence (Field-Tested)", "P250", "Valence", "Field-Tested", Rarity.MIL_SPEC, 0.20),
        Skin("mp7-urban-hazard-ft", "MP7 | Urban Hazard (Field-Tested)", "MP7", "Urban Hazard", "Field-Tested", Rarity.MIL_SPEC, 0.22),
        Skin("m4-magnesium-ft", "M4A4 | Magnesium (Field-Tested)", "M4A4", "Magnesium", "Field-Tested", Rarity.MIL_SPEC, 0.35),
        Skin("usp-ticket-ft", "USP-S | Ticket to Hell (Field-Tested)", "USP-S", "Ticket to Hell", "Field-Tested", Rarity.RESTRICTED, 0.65),
        Skin("ak-uncharted-ft", "AK-47 | Uncharted (Field-Tested)", "AK-47", "Uncharted", "Field-Tested", Rarity.MIL_SPEC, 0.75),
        Skin("famas-neural-ft", "FAMAS | Neural Net (Field-Tested)", "FAMAS", "Neural Net", "Field-Tested", Rarity.RESTRICTED, 1.05),
        Skin("galil-rocket-ft", "Galil AR | Rocket Pop (Field-Tested)", "Galil AR", "Rocket Pop", "Field-Tested", Rarity.RESTRICTED, 1.25),
        Skin("glock-candy-fn", "Glock-18 | Candy Apple (Factory New)", "Glock-18", "Candy Apple", "Factory New", Rarity.MIL_SPEC, 1.40),
        Skin("mac10-disco-ft", "MAC-10 | Disco Tech (Field-Tested)", "MAC-10", "Disco Tech", "Field-Tested", Rarity.CLASSIFIED, 2.10),
        Skin("awp-paw-ft", "AWP | PAW (Field-Tested)", "AWP", "PAW", "Field-Tested", Rarity.RESTRICTED, 3.10),
        Skin("usp-cortex-ft", "USP-S | Cortex (Field-Tested)", "USP-S", "Cortex", "Field-Tested", Rarity.CLASSIFIED, 3.60),
        Skin("deagle-mecha-ft", "Desert Eagle | Mecha Industries (Field-Tested)", "Desert Eagle", "Mecha Industries", "Field-Tested", Rarity.CLASSIFIED, 4.60),
        Skin("glock-water-ft", "Glock-18 | Water Elemental (Field-Tested)", "Glock-18", "Water Elemental", "Field-Tested", Rarity.CLASSIFIED, 5.00),
        Skin("ak-slate-ft", "AK-47 | Slate (Field-Tested)", "AK-47", "Slate", "Field-Tested", Rarity.RESTRICTED, 5.30),
        Skin("m4-neo-noir-ft", "M4A4 | Neo-Noir (Field-Tested)", "M4A4", "Neo-Noir", "Field-Tested", Rarity.COVERT, 6.40),
        Skin("awp-atheris-ft", "AWP | Atheris (Field-Tested)", "AWP", "Atheris", "Field-Tested", Rarity.RESTRICTED, 7.20),
        Skin("glock-vogue-ft", "Glock-18 | Vogue (Field-Tested)", "Glock-18", "Vogue", "Field-Tested", Rarity.CLASSIFIED, 8.50),
        Skin("m4-temukau-ft", "M4A4 | Temukau (Field-Tested)", "M4A4", "Temukau", "Field-Tested", Rarity.COVERT, 13.50),
        Skin("m4-decimator-ft", "M4A1-S | Decimator (Field-Tested)", "M4A1-S", "Decimator", "Field-Tested", Rarity.CLASSIFIED, 15.50),
        Skin("usp-traitor-ft", "USP-S | The Traitor (Field-Tested)", "USP-S", "The Traitor", "Field-Tested", Rarity.COVERT, 20.00),
        Skin("ak-redline-ft", "AK-47 | Redline (Field-Tested)", "AK-47", "Redline", "Field-Tested", Rarity.CLASSIFIED, 24.00),
        Skin("m4-player-two-ft", "M4A1-S | Player Two (Field-Tested)", "M4A1-S", "Player Two", "Field-Tested", Rarity.COVERT, 25.00),
        Skin("awp-neo-noir-ft", "AWP | Neo-Noir (Field-Tested)", "AWP", "Neo-Noir", "Field-Tested", Rarity.COVERT, 28.00),
        Skin("ak-frontside-ft", "AK-47 | Frontside Misty (Field-Tested)", "AK-47", "Frontside Misty", "Field-Tested", Rarity.CLASSIFIED, 30.00),
        Skin("awp-hyperbeast-ft", "AWP | Hyper Beast (Field-Tested)", "AWP", "Hyper Beast", "Field-Tested", Rarity.COVERT, 32.00),
        Skin("m4-emperor-ft", "M4A4 | The Emperor (Field-Tested)", "M4A4", "The Emperor", "Field-Tested", Rarity.COVERT, 36.00),
        Skin("awp-containment-ft", "AWP | Containment Breach (Field-Tested)", "AWP", "Containment Breach", "Field-Tested", Rarity.COVERT, 40.00),
        Skin("ak-empress-ft", "AK-47 | The Empress (Field-Tested)", "AK-47", "The Empress", "Field-Tested", Rarity.COVERT, 41.00),
        Skin("deagle-printstream-ft", "Desert Eagle | Printstream (Field-Tested)", "Desert Eagle", "Printstream", "Field-Tested", Rarity.COVERT, 42.00),
        Skin("ak-neon-rider-ft", "AK-47 | Neon Rider (Field-Tested)", "AK-47", "Neon Rider", "Field-Tested", Rarity.COVERT, 42.00),
        Skin("m4-hyperbeast-ft", "M4A1-S | Hyper Beast (Field-Tested)", "M4A1-S", "Hyper Beast", "Field-Tested", Rarity.COVERT, 46.00),
        Skin("usp-printstream-ft", "USP-S | Printstream (Field-Tested)", "USP-S", "Printstream", "Field-Tested", Rarity.COVERT, 55.00),
        Skin("usp-kill-confirmed-ft", "USP-S | Kill Confirmed (Field-Tested)", "USP-S", "Kill Confirmed", "Field-Tested", Rarity.COVERT, 60.00),
        Skin("ak-bloodsport-ft", "AK-47 | Bloodsport (Field-Tested)", "AK-47", "Bloodsport", "Field-Tested", Rarity.COVERT, 94.00),
        Skin("awp-asiimov-ft", "AWP | Asiimov (Field-Tested)", "AWP", "Asiimov", "Field-Tested", Rarity.COVERT, 105.00),
        Skin("ak-fuel-injector-ft", "AK-47 | Fuel Injector (Field-Tested)", "AK-47", "Fuel Injector", "Field-Tested", Rarity.COVERT, 130.00),
        Skin("m4-asiimov-ft", "M4A4 | Asiimov (Field-Tested)", "M4A4", "Asiimov", "Field-Tested", Rarity.COVERT, 180.00),
        Skin("m4-printstream-ft", "M4A1-S | Printstream (Field-Tested)", "M4A1-S", "Printstream", "Field-Tested", Rarity.COVERT, 185.00),
        Skin("navaja-doppler-fn", "★ Navaja Knife | Doppler (Factory New)", "Navaja Knife", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 250.00),
        Skin("ak-casehardened-ft", "AK-47 | Case Hardened (Field-Tested)", "AK-47", "Case Hardened", "Field-Tested", Rarity.CLASSIFIED, 270.00),
        Skin("ak-vulcan-ft", "AK-47 | Vulcan (Field-Tested)", "AK-47", "Vulcan", "Field-Tested", Rarity.COVERT, 285.00),
        Skin("awp-oni-taiji-ft", "AWP | Oni Taiji (Field-Tested)", "AWP", "Oni Taiji", "Field-Tested", Rarity.COVERT, 300.00),
        Skin("huntsman-doppler-fn", "★ Huntsman Knife | Doppler (Factory New)", "Huntsman Knife", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 500.00),
        Skin("deagle-blaze-fn", "Desert Eagle | Blaze (Factory New)", "Desert Eagle", "Blaze", "Factory New", Rarity.RESTRICTED, 560.00),
        Skin("m4-blue-phosphor-fn", "M4A1-S | Blue Phosphor (Factory New)", "M4A1-S", "Blue Phosphor", "Factory New", Rarity.CLASSIFIED, 700.00),
        Skin("awp-lightning-fn", "AWP | Lightning Strike (Factory New)", "AWP", "Lightning Strike", "Factory New", Rarity.COVERT, 720.00),
        Skin("bayonet-doppler-fn", "★ Bayonet | Doppler (Factory New)", "Bayonet", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 800.00),
        Skin("ak-fire-serpent-ft", "AK-47 | Fire Serpent (Field-Tested)", "AK-47", "Fire Serpent", "Field-Tested", Rarity.COVERT, 800.00),
        Skin("talon-doppler-fn", "★ Talon Knife | Doppler (Factory New)", "Talon Knife", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 1_300.00),
        Skin("glock-fade-fn", "Glock-18 | Fade (Factory New)", "Glock-18", "Fade", "Factory New", Rarity.RESTRICTED, 1_400.00),
        Skin("m9-doppler-fn", "★ M9 Bayonet | Doppler (Factory New)", "M9 Bayonet", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 1_750.00),
        Skin("karambit-doppler-fn", "★ Karambit | Doppler (Factory New)", "Karambit", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 1_900.00),
        Skin("awp-medusa-ww", "AWP | Medusa (Well-Worn)", "AWP", "Medusa", "Well-Worn", Rarity.COVERT, 2_000.00),
        Skin("karambit-fade-fn", "★ Karambit | Fade (Factory New)", "Karambit", "Fade", "Factory New", Rarity.EXTRAORDINARY, 2_500.00),
        Skin("butterfly-doppler-fn", "★ Butterfly Knife | Doppler (Factory New)", "Butterfly Knife", "Doppler", "Factory New", Rarity.EXTRAORDINARY, 3_400.00),
        Skin("butterfly-fade-fn", "★ Butterfly Knife | Fade (Factory New)", "Butterfly Knife", "Fade", "Factory New", Rarity.EXTRAORDINARY, 3_500.00),
        Skin("awp-dragon-lore-ft", "AWP | Dragon Lore (Field-Tested)", "AWP", "Dragon Lore", "Field-Tested", Rarity.COVERT, 6_000.00),
    )

    private fun s(id: String) = skins.first { it.id == id }
    private fun d(id: String, weight: Int) = CaseDrop(s(id), weight)

    val cases = listOf(
        GameCase("pocket-change", "Pocket Change", "Tiny price, wide variance", 100, 0xFF7CFF77, 39,
            listOf(d("p250-valence-ft", 28), d("mp7-urban-hazard-ft", 24), d("m4-magnesium-ft", 18), d("usp-ticket-ft", 12), d("glock-candy-fn", 10), d("mac10-disco-ft", 6), d("awp-paw-ft", 2))),
        GameCase("starter", "Starter Drop", "Cheap rifles & pistols", 250, 0xFF8CFF5B, 34,
            listOf(d("m4-magnesium-ft", 20), d("ak-uncharted-ft", 19), d("famas-neural-ft", 17), d("galil-rocket-ft", 15), d("mac10-disco-ft", 12), d("awp-paw-ft", 8), d("glock-water-ft", 6), d("glock-vogue-ft", 3))),
        GameCase("pistol-club", "Pistol Club", "USP, Glock and Deagle", 600, 0xFFFF78B9, 15,
            listOf(d("usp-ticket-ft", 20), d("glock-candy-fn", 18), d("usp-cortex-ft", 17), d("deagle-mecha-ft", 15), d("glock-water-ft", 12), d("glock-vogue-ft", 9), d("usp-traitor-ft", 5), d("deagle-printstream-ft", 3), d("usp-kill-confirmed-ft", 1))),
        GameCase("budget-rifle", "Budget Rifle", "Affordable AK and M4 pool", 900, 0xFF53D8FF, 25,
            listOf(d("ak-uncharted-ft", 17), d("ak-slate-ft", 17), d("m4-neo-noir-ft", 15), d("m4-temukau-ft", 14), d("m4-decimator-ft", 12), d("ak-redline-ft", 10), d("m4-player-two-ft", 7), d("ak-frontside-ft", 5), d("m4-emperor-ft", 3))),
        GameCase("awp-lab", "AWP Lab", "From PAW to Asiimov", 1_500, 0xFF9B8CFF, 10,
            listOf(d("awp-paw-ft", 20), d("awp-atheris-ft", 20), d("awp-neo-noir-ft", 17), d("awp-hyperbeast-ft", 15), d("awp-containment-ft", 12), d("awp-asiimov-ft", 9), d("awp-oni-taiji-ft", 5), d("awp-lightning-fn", 2))),
        GameCase("rifle-rush", "Rifle Rush", "AK & M4 focused", 2_500, 0xFF44D7FF, 20,
            listOf(d("m4-temukau-ft", 18), d("m4-decimator-ft", 17), d("ak-redline-ft", 16), d("m4-player-two-ft", 13), d("ak-frontside-ft", 11), d("m4-emperor-ft", 9), d("ak-empress-ft", 7), d("m4-hyperbeast-ft", 5), d("ak-bloodsport-ft", 3), d("ak-vulcan-ft", 1))),
        GameCase("neon-night", "Neon Night", "Bright premium finishes", 3_500, 0xFFFF59E8, 30,
            listOf(d("glock-vogue-ft", 17), d("m4-temukau-ft", 15), d("awp-neo-noir-ft", 14), d("m4-emperor-ft", 13), d("ak-empress-ft", 11), d("ak-neon-rider-ft", 10), d("usp-printstream-ft", 8), d("ak-bloodsport-ft", 6), d("m4-printstream-ft", 4), d("ak-vulcan-ft", 2))),
        GameCase("red-tier", "Red Tier", "Covert-heavy case", 5_000, 0xFFFF5266, 13,
            listOf(d("m4-emperor-ft", 18), d("awp-containment-ft", 16), d("ak-empress-ft", 15), d("deagle-printstream-ft", 14), d("m4-hyperbeast-ft", 12), d("usp-printstream-ft", 10), d("usp-kill-confirmed-ft", 7), d("ak-bloodsport-ft", 5), d("awp-asiimov-ft", 2), d("m4-printstream-ft", 1))),
        GameCase("hundred-club", "$100 Club", "Mid/high-tier rifles", 10_000, 0xFFFFA95E, 0,
            listOf(d("ak-bloodsport-ft", 22), d("awp-asiimov-ft", 18), d("ak-fuel-injector-ft", 16), d("m4-asiimov-ft", 13), d("m4-printstream-ft", 11), d("ak-casehardened-ft", 8), d("ak-vulcan-ft", 6), d("awp-oni-taiji-ft", 4), d("deagle-blaze-fn", 2))),
        GameCase("classified-vault", "Classified Vault", "Collectors and classics", 20_000, 0xFFCD64FF, 11,
            listOf(d("ak-fuel-injector-ft", 18), d("m4-asiimov-ft", 17), d("m4-printstream-ft", 15), d("navaja-doppler-fn", 13), d("ak-casehardened-ft", 11), d("ak-vulcan-ft", 10), d("awp-oni-taiji-ft", 8), d("huntsman-doppler-fn", 5), d("deagle-blaze-fn", 2), d("awp-lightning-fn", 1))),
        GameCase("collector", "Collector", "Rare market pieces", 35_000, 0xFFFFC857, 12,
            listOf(d("navaja-doppler-fn", 20), d("ak-casehardened-ft", 17), d("ak-vulcan-ft", 16), d("awp-oni-taiji-ft", 14), d("huntsman-doppler-fn", 11), d("deagle-blaze-fn", 9), d("m4-blue-phosphor-fn", 6), d("awp-lightning-fn", 4), d("bayonet-doppler-fn", 2), d("talon-doppler-fn", 1))),
        GameCase("blue-gem", "Blue Gem", "Case Hardened and blue icons", 50_000, 0xFF4E8CFF, 36,
            listOf(d("ak-casehardened-ft", 27), d("awp-oni-taiji-ft", 18), d("huntsman-doppler-fn", 15), d("m4-blue-phosphor-fn", 12), d("awp-lightning-fn", 10), d("bayonet-doppler-fn", 8), d("ak-fire-serpent-ft", 5), d("talon-doppler-fn", 3), d("m9-doppler-fn", 1), d("karambit-doppler-fn", 1))),
        GameCase("knife-entry", "Knife Entry", "First step into knives", 45_000, 0xFFFFB45C, 30,
            listOf(d("ak-vulcan-ft", 22), d("awp-oni-taiji-ft", 18), d("navaja-doppler-fn", 17), d("huntsman-doppler-fn", 15), d("deagle-blaze-fn", 11), d("m4-blue-phosphor-fn", 7), d("bayonet-doppler-fn", 5), d("talon-doppler-fn", 3), d("m9-doppler-fn", 1), d("karambit-doppler-fn", 1))),
        GameCase("fire-ice", "Fire & Ice", "Serpents, fades and dopplers", 75_000, 0xFFFF6A54, 5,
            listOf(d("deagle-blaze-fn", 20), d("m4-blue-phosphor-fn", 18), d("awp-lightning-fn", 17), d("bayonet-doppler-fn", 15), d("ak-fire-serpent-ft", 12), d("talon-doppler-fn", 8), d("glock-fade-fn", 5), d("m9-doppler-fn", 3), d("karambit-doppler-fn", 1), d("karambit-fade-fn", 1))),
        GameCase("knife-vault", "Knife Vault", "Doppler-heavy knife pool", 100_000, 0xFFFF8A3D, 33,
            listOf(d("navaja-doppler-fn", 17), d("huntsman-doppler-fn", 17), d("bayonet-doppler-fn", 16), d("talon-doppler-fn", 15), d("glock-fade-fn", 12), d("m9-doppler-fn", 10), d("karambit-doppler-fn", 7), d("karambit-fade-fn", 3), d("butterfly-doppler-fn", 2), d("butterfly-fade-fn", 1))),
        GameCase("doppler-royal", "Doppler Royal", "High-roller Doppler selection", 175_000, 0xFFBE70FF, 40,
            listOf(d("bayonet-doppler-fn", 19), d("talon-doppler-fn", 18), d("glock-fade-fn", 15), d("m9-doppler-fn", 14), d("karambit-doppler-fn", 12), d("awp-medusa-ww", 9), d("karambit-fade-fn", 6), d("butterfly-doppler-fn", 4), d("butterfly-fade-fn", 2), d("awp-dragon-lore-ft", 1))),
        GameCase("medusa", "Medusa", "AWP legends and premium knives", 225_000, 0xFF54E0D1, 15,
            listOf(d("glock-fade-fn", 18), d("m9-doppler-fn", 17), d("karambit-doppler-fn", 16), d("awp-medusa-ww", 15), d("karambit-fade-fn", 12), d("butterfly-doppler-fn", 9), d("butterfly-fade-fn", 7), d("awp-dragon-lore-ft", 6))),
        GameCase("dragon-vault", "Dragon Vault", "Top-end collector simulator", 300_000, 0xFFFFD95A, 31,
            listOf(d("m9-doppler-fn", 19), d("karambit-doppler-fn", 18), d("awp-medusa-ww", 16), d("karambit-fade-fn", 15), d("butterfly-doppler-fn", 12), d("butterfly-fade-fn", 10), d("awp-dragon-lore-ft", 10))),
    )

    fun case(id: String): GameCase = cases.first { it.id == id }

    fun roll(
        gameCase: GameCase,
        profitChancePercent: Int = gameCase.defaultProfitChancePercent,
        priceUsd: (Skin) -> Double = { it.fallbackUsd },
        random: Random = Random.Default,
    ): Skin {
        val targetProfit = random.nextInt(100) < profitChancePercent.coerceIn(0, 100)
        val costUsd = gameCase.costCredits / 100.0
        val bucket = gameCase.drops.filter { drop ->
            val profitable = priceUsd(drop.skin) >= costUsd
            profitable == targetProfit
        }
        return weightedRoll(if (bucket.isNotEmpty()) bucket else gameCase.drops, random)
    }

    private fun weightedRoll(drops: List<CaseDrop>, random: Random): Skin {
        val total = drops.sumOf { it.weight }.coerceAtLeast(1)
        var cursor = random.nextInt(total)
        for (drop in drops) {
            if (cursor < drop.weight) return drop.skin
            cursor -= drop.weight
        }
        return drops.last().skin
    }

    fun expectedRtpPercent(gameCase: GameCase, profitChancePercent: Int): Double {
        val costUsd = gameCase.costCredits / 100.0
        if (costUsd <= 0.0) return 0.0
        val profit = gameCase.drops.filter { it.skin.fallbackUsd >= costUsd }
        val loss = gameCase.drops.filter { it.skin.fallbackUsd < costUsd }

        fun weightedAverage(pool: List<CaseDrop>): Double {
            if (pool.isEmpty()) return 0.0
            val totalWeight = pool.sumOf { it.weight }.coerceAtLeast(1)
            return pool.sumOf { it.skin.fallbackUsd * it.weight } / totalWeight
        }

        val p = profitChancePercent.coerceIn(0, 100) / 100.0
        val expected = when {
            profit.isEmpty() -> weightedAverage(loss)
            loss.isEmpty() -> weightedAverage(profit)
            else -> weightedAverage(profit) * p + weightedAverage(loss) * (1.0 - p)
        }
        return expected / costUsd * 100.0
    }

    fun hasBothOutcomeBuckets(gameCase: GameCase): Boolean {
        val costUsd = gameCase.costCredits / 100.0
        return gameCase.drops.any { it.skin.fallbackUsd >= costUsd } &&
            gameCase.drops.any { it.skin.fallbackUsd < costUsd }
    }

    fun closestByFallbackPrice(targetUsd: Double): Skin = skins.minBy { abs(it.fallbackUsd - targetUsd) }
}
