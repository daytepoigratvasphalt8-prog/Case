package com.caseforge.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caseforge.app.data.DemoCatalog
import com.caseforge.app.data.SteamMarketClient
import com.caseforge.app.model.BattleResult
import com.caseforge.app.model.CaseStats
import com.caseforge.app.model.GameCase
import com.caseforge.app.model.MarketInfo
import com.caseforge.app.model.OwnedSkin
import com.caseforge.app.model.Rarity
import com.caseforge.app.model.Screen
import com.caseforge.app.model.Skin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt
import kotlin.random.Random

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF11151D)
private val Panel2 = Color(0xFF171C26)
private val Muted = Color(0xFF8E98A8)
private val Lime = Color(0xFF9CFF57)
private val Danger = Color(0xFFFF5266)

private val colors = darkColorScheme(
    primary = Lime,
    onPrimary = Color(0xFF0B1207),
    background = Bg,
    surface = Panel,
    onBackground = Color.White,
    onSurface = Color.White,
)

private class DemoState(context: Context) {
    companion object {
        const val ADMIN_USER = "admin"
        const val ADMIN_PASSWORD = "caseforge"
    }

    private val prefs = context.getSharedPreferences("caseforge_demo", Context.MODE_PRIVATE)

    var credits by mutableIntStateOf(25_000)
    var screen by mutableStateOf<Screen>(Screen.Home)
    var lastBattle by mutableStateOf<BattleResult?>(null)
    var notice by mutableStateOf<String?>(null)
    var isAdmin by mutableStateOf(false)
    private var inventorySeq by mutableLongStateOf(1L)
    val inventory = mutableStateListOf<OwnedSkin>()
    val profitChanceByCase = mutableStateMapOf<String, Int>().apply {
        DemoCatalog.cases.forEach {
            put(it.id, prefs.getInt("profit_chance_${it.id}", it.defaultProfitChancePercent).coerceIn(0, 100))
        }
    }
    val caseStats = mutableStateMapOf<String, CaseStats>().apply {
        DemoCatalog.cases.forEach { put(it.id, CaseStats()) }
    }

    fun add(skin: Skin) {
        inventory += OwnedSkin(inventorySeq++, skin)
    }

    fun remove(item: OwnedSkin) {
        inventory.remove(item)
    }

    fun marketUsd(skin: Skin): Double =
        SteamMarketClient.cached(skin.marketHashName)?.lowestPriceUsd ?: skin.fallbackUsd

    fun sell(item: OwnedSkin) {
        val payout = (marketUsd(item.skin) * 100).roundToInt().coerceAtLeast(1)
        remove(item)
        credits += payout
        notice = "+$payout demo credits"
    }

    fun startOpen(gameCase: GameCase) {
        if (credits < gameCase.costCredits) {
            notice = "Not enough demo credits"
            return
        }
        credits -= gameCase.costCredits
        screen = Screen.Opening(gameCase.id)
    }

    fun profitChance(gameCase: GameCase): Int =
        profitChanceByCase[gameCase.id] ?: gameCase.defaultProfitChancePercent

    fun setProfitChance(gameCase: GameCase, value: Int) {
        val safe = value.coerceIn(0, 100)
        profitChanceByCase[gameCase.id] = safe
        prefs.edit().putInt("profit_chance_${gameCase.id}", safe).apply()
    }

    fun roll(gameCase: GameCase): Skin = DemoCatalog.roll(
        gameCase = gameCase,
        profitChancePercent = profitChance(gameCase),
        priceUsd = ::marketUsd,
    )

    fun recordRoll(gameCase: GameCase, skin: Skin) {
        val old = caseStats[gameCase.id] ?: CaseStats()
        val profitable = marketUsd(skin) * 100.0 >= gameCase.costCredits
        caseStats[gameCase.id] = old.copy(
            opens = old.opens + 1,
            profitable = old.profitable + if (profitable) 1 else 0,
        )
    }

    fun loginAdmin(user: String, password: String): Boolean {
        val ok = user == ADMIN_USER && password == ADMIN_PASSWORD
        isAdmin = ok
        notice = if (ok) "Admin demo mode enabled" else "Invalid admin credentials"
        if (ok) screen = Screen.AdminPanel
        return ok
    }

    fun logoutAdmin() {
        isAdmin = false
        screen = Screen.Home
        notice = "Admin logged out"
    }

    fun resetOdds() {
        DemoCatalog.cases.forEach {
            profitChanceByCase[it.id] = it.defaultProfitChancePercent
            prefs.edit().putInt("profit_chance_${it.id}", it.defaultProfitChancePercent).apply()
        }
        notice = "Default case odds restored"
    }

    fun resetStats() {
        DemoCatalog.cases.forEach { caseStats[it.id] = CaseStats() }
        notice = "Case statistics reset"
    }
}

@Composable
fun CaseForgeApp() {
    val context = LocalContext.current
    val state = remember { DemoState(context) }
    MaterialTheme(colorScheme = colors) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            val topLevel = state.screen is Screen.Home || state.screen is Screen.Battles ||
                state.screen is Screen.Upgrade || state.screen is Screen.Contract || state.screen is Screen.Inventory

            BackHandler(enabled = !topLevel) { state.screen = Screen.Home }

            Scaffold(
                containerColor = Bg,
                topBar = {
                    Header(
                        credits = state.credits,
                        canBack = !topLevel,
                        isAdmin = state.isAdmin,
                        onBack = { state.screen = Screen.Home },
                        onAdmin = { state.screen = if (state.isAdmin) Screen.AdminPanel else Screen.AdminLogin },
                        onReset = {
                            state.credits = 25_000
                            state.inventory.clear()
                            state.notice = "Demo reset"
                        }
                    )
                },
                bottomBar = {
                    if (topLevel) BottomNav(state.screen) { state.screen = it }
                }
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    when (val screen = state.screen) {
                        Screen.Home -> HomeScreen(state)
                        is Screen.CaseDetails -> CaseDetailsScreen(state, DemoCatalog.case(screen.caseId))
                        is Screen.Opening -> OpeningScreen(state, DemoCatalog.case(screen.caseId))
                        Screen.Battles -> BattlesScreen(state)
                        Screen.Upgrade -> UpgradeScreen(state)
                        Screen.Contract -> ContractScreen(state)
                        Screen.Inventory -> InventoryScreen(state)
                        Screen.AdminLogin -> AdminLoginScreen(state)
                        Screen.AdminPanel -> AdminPanelScreen(state)
                    }

                    state.notice?.let { message ->
                        LaunchedEffect(message) {
                            delay(1800)
                            state.notice = null
                        }
                        Surface(
                            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                            color = Color(0xEE202734),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = .08f))
                        ) {
                            Text(message, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(credits: Int, canBack: Boolean, isAdmin: Boolean, onBack: () -> Unit, onAdmin: () -> Unit, onReset: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Bg)
            .padding(WindowInsets.statusBars.asPaddingValues())
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (canBack) {
                Text("‹", fontSize = 34.sp, modifier = Modifier.clickable { onBack() }.padding(end = 10.dp))
            }
            Column(Modifier.weight(1f)) {
                Text("CASEFORGE", fontWeight = FontWeight.Black, fontSize = 19.sp, letterSpacing = 1.6.sp)
                Text("CS2 case simulator", color = Muted, fontSize = 11.sp)
            }
            Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.End) {
                    Text("$credits CR", color = Lime, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("demo only", color = Muted, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.width(8.dp))
            Surface(
                modifier = Modifier.clickable { onAdmin() },
                color = if (isAdmin) Lime.copy(alpha = .16f) else Panel2,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(if (isAdmin) "ADMIN" else "ADM", color = if (isAdmin) Lime else Muted, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp))
            }
            Spacer(Modifier.width(5.dp))
            Text("↻", fontSize = 22.sp, modifier = Modifier.clickable { onReset() }.padding(6.dp))
        }
    }
}

@Composable
private fun BottomNav(screen: Screen, onSelect: (Screen) -> Unit) {
    val items = listOf(
        "Cases" to Screen.Home,
        "Battles" to Screen.Battles,
        "Upgrade" to Screen.Upgrade,
        "Contract" to Screen.Contract,
        "Inventory" to Screen.Inventory,
    )
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(WindowInsets.navigationBars.asPaddingValues())
            .padding(horizontal = 6.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (label, target) ->
            val active = screen::class == target::class
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onSelect(target) }.padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(5.dp).clip(CircleShape).background(if (active) Lime else Color.Transparent))
                Spacer(Modifier.height(4.dp))
                Text(label, color = if (active) Color.White else Muted, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
private fun HomeScreen(state: DemoState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            HeroBanner()
        }
        item {
            SectionTitle("Popular cases", "Real CS2 item names • live Steam price lookup")
        }
        item {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxWidth().height((((DemoCatalog.cases.size + 1) / 2) * 225).dp),
                userScrollEnabled = false,
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(DemoCatalog.cases) { gameCase ->
                    CaseCard(gameCase, state.profitChance(gameCase)) { state.screen = Screen.CaseDetails(gameCase.id) }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Simulator mode", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(
                    "No deposits, withdrawals or Steam trades are implemented. Market prices are informational; opening costs use separate demo credits.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
private fun HeroBanner() {
    Box(
        Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .height(170.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1A2A16), Color(0xFF10151D), Color(0xFF171325))))
            .border(1.dp, Color.White.copy(alpha = .06f), RoundedCornerShape(24.dp))
            .padding(20.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(.68f)) {
            Surface(color = Lime.copy(alpha = .15f), shape = RoundedCornerShape(50)) {
                Text("MOBILE MVP", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("Open. Battle. Upgrade.", fontSize = 27.sp, lineHeight = 29.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(7.dp))
            Text("Original dark UI inspired by case-opening platforms.", color = Muted, fontSize = 12.sp)
        }
        Box(
            Modifier.align(Alignment.CenterEnd).size(94.dp).clip(RoundedCornerShape(24.dp)).background(Lime.copy(alpha = .12f)),
            contentAlignment = Alignment.Center
        ) {
            Text("◆", color = Lime, fontSize = 58.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 16.dp)) {
        Text(title, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CaseCard(gameCase: GameCase, profitChance: Int, onClick: () -> Unit) {
    val accent = Color(gameCase.accent)
    val hero = gameCase.drops.minBy { it.weight }.skin
    Card(
        modifier = Modifier.fillMaxWidth().height(215.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = .22f))
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier.fillMaxWidth().height(118.dp).background(
                    Brush.verticalGradient(listOf(accent.copy(alpha = .22f), Color.Transparent))
                )
            )
            SkinImage(hero, Modifier.align(Alignment.TopCenter).padding(top = 8.dp).size(130.dp, 96.dp))
            Column(Modifier.align(Alignment.BottomStart).padding(13.dp)) {
                Text(gameCase.title, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(gameCase.subtitle, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Profit $profitChance% • Loss ${100 - profitChance}%", color = Muted, fontSize = 9.sp)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${gameCase.costCredits} CR", color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${gameCase.drops.size} drops", color = Muted, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun CaseDetailsScreen(state: DemoState, gameCase: GameCase) {
    val accent = Color(gameCase.accent)
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp))
                        .background(Brush.radialGradient(listOf(accent.copy(alpha = .28f), Panel)))
                ) {
                    val hero = gameCase.drops.minBy { it.weight }.skin
                    SkinImage(hero, Modifier.align(Alignment.Center).size(230.dp, 150.dp))
                }
                Spacer(Modifier.height(14.dp))
                Text(gameCase.title, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text(gameCase.subtitle, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { state.startOpen(gameCase) },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF0A0C0F))
                ) {
                    Text("OPEN • ${gameCase.costCredits} CR", fontWeight = FontWeight.Black)
                }
            }
        }
        item {
            val profitChance = state.profitChance(gameCase)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color.White.copy(alpha = .06f))) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("PROFIT", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        Text("$profitChance%", fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("LOSS", color = Danger, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        Text("${100 - profitChance}%", fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        item {
            Text("Possible drops", fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        items(gameCase.drops.sortedBy { it.weight }) { drop ->
            DropRow(gameCase, drop.skin, drop.weight, state.profitChance(gameCase))
        }
    }
}

@Composable
private fun DropRow(gameCase: GameCase, skin: Skin, weight: Int, profitChance: Int) {
    val costUsd = gameCase.costCredits / 100.0
    val profitable = skin.fallbackUsd >= costUsd
    val bucketWeight = gameCase.drops
        .filter { (it.skin.fallbackUsd >= costUsd) == profitable }
        .sumOf { it.weight }
        .coerceAtLeast(1)
    val bucketChance = if (profitable) profitChance else 100 - profitChance
    val effectiveChance = bucketChance * weight.toDouble() / bucketWeight

    Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, rarityColor(skin.rarity).copy(alpha = .25f))) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SkinImage(skin, Modifier.size(82.dp, 58.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(skin.weapon, color = Muted, fontSize = 10.sp)
                Text(skin.finish, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(skin.wear, color = rarityColor(skin.rarity), fontSize = 9.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${"%.2f".format(effectiveChance)}%", fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(if (profitable) "profit pool" else "loss pool", color = if (profitable) Lime else Danger, fontSize = 8.sp)
                LivePrice(skin)
            }
        }
    }
}

@Composable
private fun OpeningScreen(state: DemoState, gameCase: GameCase) {
    var current by remember { mutableStateOf(gameCase.drops.first().skin) }
    var result by remember { mutableStateOf<Skin?>(null) }
    var added by remember { mutableStateOf(false) }

    LaunchedEffect(gameCase.id) {
        repeat(24) {
            current = gameCase.drops.random().skin
            delay(55L + it * 4L)
        }
        val winner = state.roll(gameCase)
        state.recordRoll(gameCase, winner)
        current = winner
        result = winner
    }

    LaunchedEffect(result) {
        val win = result ?: return@LaunchedEffect
        if (!added) {
            state.add(win)
            added = true
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Text(if (result == null) "OPENING ${gameCase.title.uppercase()}" else "YOU GOT", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(26.dp))
        AnimatedContent(current, label = "case-roll") { skin ->
            Surface(
                modifier = Modifier.fillMaxWidth().height(330.dp),
                color = Panel,
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, rarityColor(skin.rarity).copy(alpha = .55f))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    SkinImage(skin, Modifier.fillMaxWidth().height(190.dp).padding(20.dp))
                    Text(skin.weapon, color = Muted, fontSize = 12.sp)
                    Text(skin.finish, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    Text(skin.wear, color = rarityColor(skin.rarity), fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    LivePrice(skin, large = true)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        if (result != null) {
            Text("Added to demo inventory", color = Lime, fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { state.startOpen(gameCase) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(gameCase.accent), contentColor = Bg)
            ) { Text("OPEN AGAIN • ${gameCase.costCredits} CR", fontWeight = FontWeight.Black) }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { state.screen = Screen.Inventory }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Text("VIEW INVENTORY")
            }
        } else {
            Text("Rolling…", color = Muted)
        }
    }
}

@Composable
private fun BattlesScreen(state: DemoState) {
    var selected by remember { mutableStateOf(DemoCatalog.cases[1]) }
    val last = state.lastBattle
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { SectionTitleInline("Case battle", "1v1 against a local bot • winner takes both demo drops") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(DemoCatalog.cases) { gameCase ->
                    val active = selected.id == gameCase.id
                    Surface(
                        modifier = Modifier.width(155.dp).clickable { selected = gameCase },
                        color = if (active) Color(gameCase.accent).copy(alpha = .13f) else Panel,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, if (active) Color(gameCase.accent) else Color.White.copy(alpha = .05f))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(gameCase.title, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            Spacer(Modifier.height(5.dp))
                            Text("${gameCase.costCredits} CR", color = Color(gameCase.accent), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    if (state.credits < selected.costCredits) {
                        state.notice = "Not enough demo credits"
                    } else {
                        state.credits -= selected.costCredits
                        val p = state.roll(selected)
                        val o = state.roll(selected)
                        state.recordRoll(selected, p)
                        state.recordRoll(selected, o)
                        val pv = SteamMarketClient.cached(p.marketHashName)?.lowestPriceUsd ?: p.fallbackUsd
                        val ov = SteamMarketClient.cached(o.marketHashName)?.lowestPriceUsd ?: o.fallbackUsd
                        val won = pv >= ov
                        state.lastBattle = BattleResult(p, o, won)
                        if (won) {
                            state.add(p)
                            state.add(o)
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)
            ) { Text("START 1V1 • ${selected.costCredits} CR", fontWeight = FontWeight.Black) }
        }
        if (last != null) {
            item {
                Surface(color = Panel, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, if (last.won) Lime.copy(alpha = .45f) else Danger.copy(alpha = .45f))) {
                    Column(Modifier.padding(14.dp)) {
                        Text(if (last.won) "VICTORY" else "DEFEAT", color = if (last.won) Lime else Danger, fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Spacer(Modifier.height(12.dp))
                        BattleSide("YOU", last.player)
                        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color.White.copy(alpha = .06f))
                        BattleSide("BOT", last.opponent)
                        Spacer(Modifier.height(8.dp))
                        Text(if (last.won) "Both virtual drops were added to inventory." else "No items were awarded.", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BattleSide(label: String, skin: Skin) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(color = Panel2, shape = RoundedCornerShape(10.dp)) { Text(label, modifier = Modifier.padding(8.dp), fontSize = 10.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(10.dp))
        SkinImage(skin, Modifier.size(82.dp, 58.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(skin.weapon, color = Muted, fontSize = 10.sp)
            Text(skin.finish, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            LivePrice(skin)
        }
    }
}

@Composable
private fun UpgradeScreen(state: DemoState) {
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var multiplier by remember { mutableIntStateOf(2) }
    val selected = state.inventory.firstOrNull { it.inventoryId == selectedId } ?: state.inventory.firstOrNull()
    val chance = (95.0 / multiplier).coerceAtMost(90.0)

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { SectionTitleInline("Upgrade", "Risk one virtual inventory item for a higher-value catalog item") }
        if (state.inventory.isEmpty()) {
            item { EmptyPanel("Open a case first. Your virtual skins will appear here.") }
        } else {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(state.inventory, key = { it.inventoryId }) { item ->
                        val active = item.inventoryId == (selectedId ?: selected?.inventoryId)
                        MiniInventoryCard(item, active) { selectedId = item.inventoryId }
                    }
                }
            }
            item {
                Surface(color = Panel, shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Target multiplier", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(2, 3, 5).forEach { m ->
                                Surface(
                                    modifier = Modifier.weight(1f).clickable { multiplier = m },
                                    color = if (multiplier == m) Lime else Panel2,
                                    contentColor = if (multiplier == m) Bg else Color.White,
                                    shape = RoundedCornerShape(14.dp)
                                ) { Text("x$m", modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Black) }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Success chance ${"%.1f".format(chance)}%", fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text("Target value ≈ $${"%.2f".format((selected?.skin?.fallbackUsd ?: 0.0) * multiplier)}", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        val item = selected ?: return@Button
                        state.remove(item)
                        if (Random.nextDouble(100.0) < chance) {
                            val target = DemoCatalog.closestByFallbackPrice(item.skin.fallbackUsd * multiplier)
                            state.add(target)
                            state.notice = "Upgrade success"
                        } else {
                            state.notice = "Upgrade failed"
                        }
                        selectedId = null
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)
                ) { Text("TRY UPGRADE", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
private fun ContractScreen(state: DemoState) {
    val selected = remember { mutableStateListOf<Long>() }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitleInline("Contract", "Combine 3–5 virtual items into one randomized item") }
        if (state.inventory.size < 3) {
            item { EmptyPanel("You need at least 3 virtual skins in inventory.") }
        } else {
            items(state.inventory, key = { it.inventoryId }) { item ->
                val active = item.inventoryId in selected
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable {
                        if (active) selected.remove(item.inventoryId)
                        else if (selected.size < 5) selected.add(item.inventoryId)
                    },
                    color = if (active) Lime.copy(alpha = .08f) else Panel,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (active) Lime.copy(alpha = .5f) else Color.White.copy(alpha = .05f))
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(22.dp).clip(RoundedCornerShape(7.dp)).background(if (active) Lime else Panel2), contentAlignment = Alignment.Center) {
                            if (active) Text("✓", color = Bg, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(8.dp))
                        SkinImage(item.skin, Modifier.size(68.dp, 48.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.skin.weapon, color = Muted, fontSize = 9.sp)
                            Text(item.skin.finish, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        LivePrice(item.skin)
                    }
                }
            }
            item {
                val total = state.inventory.filter { it.inventoryId in selected }.sumOf {
                    SteamMarketClient.cached(it.skin.marketHashName)?.lowestPriceUsd ?: it.skin.fallbackUsd
                }
                Text("Selected ${selected.size}/5 • market value ≈ $${"%.2f".format(total)}", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Button(
                    enabled = selected.size >= 3,
                    onClick = {
                        val used = state.inventory.filter { it.inventoryId in selected }
                        val value = used.sumOf { SteamMarketClient.cached(it.skin.marketHashName)?.lowestPriceUsd ?: it.skin.fallbackUsd }
                        used.forEach(state::remove)
                        val factor = Random.nextDouble(.82, 1.19)
                        state.add(DemoCatalog.closestByFallbackPrice(value * factor))
                        selected.clear()
                        state.notice = "Contract completed"
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)
                ) { Text("CREATE CONTRACT", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
private fun InventoryScreen(state: DemoState) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionTitleInline("Inventory", "Live market lookup + virtual sell-to-credit action") }
        if (state.inventory.isEmpty()) {
            item { EmptyPanel("Inventory is empty. Open cases or win a battle.") }
        } else {
            items(state.inventory, key = { it.inventoryId }) { item ->
                InventoryRow(item, onSell = { state.sell(item) })
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Steam trade/cash-out is intentionally not implemented in this demo project.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun InventoryRow(item: OwnedSkin, onSell: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, rarityColor(item.skin.rarity).copy(alpha = .22f))) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SkinImage(item.skin, Modifier.size(90.dp, 62.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.skin.weapon, color = Muted, fontSize = 10.sp)
                Text(item.skin.finish, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(item.skin.wear, color = rarityColor(item.skin.rarity), fontSize = 9.sp)
                LivePrice(item.skin)
            }
            OutlinedButton(onClick = onSell, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp)) {
                Text("SELL", fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun MiniInventoryCard(item: OwnedSkin, active: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.width(135.dp).clickable { onClick() },
        color = if (active) Lime.copy(alpha = .09f) else Panel,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (active) Lime else Color.White.copy(alpha = .05f))
    ) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            SkinImage(item.skin, Modifier.fillMaxWidth().height(65.dp))
            Text(item.skin.weapon, color = Muted, fontSize = 9.sp, maxLines = 1)
            Text(item.skin.finish, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun AdminLoginScreen(state: DemoState) {
    var user by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Panel,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, Lime.copy(alpha = .18f))
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ADMIN / DEMO", color = Lime, fontSize = 11.sp, fontWeight = FontWeight.Black)
                Text("Simulator control panel", fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("Local demo account only. Do not use these credentials or client-side odds controls in a real-money product.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Username") }
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    label = { Text("Password") }
                )
                Button(
                    onClick = { state.loginAdmin(user.trim(), password) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)
                ) { Text("LOGIN", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
private fun AdminPanelScreen(state: DemoState) {
    if (!state.isAdmin) {
        LaunchedEffect(Unit) { state.screen = Screen.AdminLogin }
        return
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            SectionTitleInline("Admin panel", "Virtual economy, test odds and case statistics")
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("DEMO ECONOMY", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    Text("Balance: ${state.credits} CR", fontSize = 19.sp, fontWeight = FontWeight.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AdminSmallButton("+10K", Modifier.weight(1f)) { state.credits += 10_000 }
                        AdminSmallButton("+100K", Modifier.weight(1f)) { state.credits += 100_000 }
                        AdminSmallButton("1M CR", Modifier.weight(1f)) { state.credits = 1_000_000 }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AdminSmallButton("RESET ODDS", Modifier.weight(1f), state::resetOdds)
                        AdminSmallButton("RESET STATS", Modifier.weight(1f), state::resetStats)
                    }
                }
            }
        }
        item {
            Text("CASE ODDS", fontSize = 17.sp, fontWeight = FontWeight.Black)
            Text("Profit = item market/fallback value ≥ case cost. Loss is always 100% − profit.", color = Muted, fontSize = 10.sp)
        }
        items(DemoCatalog.cases, key = { it.id }) { gameCase ->
            AdminCaseOddsCard(state, gameCase)
        }
        item {
            OutlinedButton(onClick = state::logoutAdmin, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Text("LOG OUT ADMIN", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun AdminCaseOddsCard(state: DemoState, gameCase: GameCase) {
    val chance = state.profitChance(gameCase)
    val stats = state.caseStats[gameCase.id] ?: CaseStats()
    val actualProfit = if (stats.opens == 0) 0.0 else stats.profitable * 100.0 / stats.opens
    val rtp = DemoCatalog.expectedRtpPercent(gameCase, chance)

    Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(gameCase.accent).copy(alpha = .2f))) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(gameCase.title, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text("${gameCase.costCredits} CR • est. RTP ${"%.1f".format(rtp)}%", color = Muted, fontSize = 10.sp)
                }
                Text("$chance / ${100 - chance}", color = Color(gameCase.accent), fontWeight = FontWeight.Black, fontSize = 16.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(-10, -5, -1, 1, 5, 10).forEach { delta ->
                    AdminSmallButton(if (delta > 0) "+$delta" else "$delta", Modifier.weight(1f)) {
                        state.setProfitChance(gameCase, chance + delta)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(10, 25, 35, 50, 75).forEach { preset ->
                    AdminSmallButton("$preset%", Modifier.weight(1f)) { state.setProfitChance(gameCase, preset) }
                }
            }
            Text(
                "Configured: profit $chance% / loss ${100 - chance}% • observed: ${stats.profitable}/${stats.opens} profit (${"%.1f".format(actualProfit)}%)",
                color = Muted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun AdminSmallButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(10.dp)).clickable { onClick() },
        color = Panel2,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .06f))
    ) {
        Text(label, modifier = Modifier.padding(vertical = 9.dp), textAlign = TextAlign.Center, fontSize = 9.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun SectionTitleInline(title: String, subtitle: String) {
    Column {
        Text(title, fontWeight = FontWeight.Black, fontSize = 23.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun EmptyPanel(text: String) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
        Text(text, modifier = Modifier.fillMaxWidth().padding(20.dp), color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun LivePrice(skin: Skin, large: Boolean = false) {
    val info by marketInfo(skin)
    val label = info.lowestPriceLabel ?: "~$${"%.2f".format(skin.fallbackUsd)}"
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(if (large) 7.dp else 5.dp).clip(CircleShape).background(if (info.isLive) Lime else Muted))
        Spacer(Modifier.width(5.dp))
        Text(
            label,
            color = if (info.isLive) Color.White else Muted,
            fontWeight = if (large) FontWeight.Black else FontWeight.SemiBold,
            fontSize = if (large) 16.sp else 10.sp
        )
        if (!info.isLive && large) Text("  fallback", color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun marketInfo(skin: Skin) = produceState(
    initialValue = SteamMarketClient.cached(skin.marketHashName) ?: MarketInfo(),
    key1 = skin.marketHashName
) {
    value = SteamMarketClient.load(skin)
}

@Composable
private fun SkinImage(skin: Skin, modifier: Modifier = Modifier) {
    val info by marketInfo(skin)
    val bitmap by networkBitmap(info.imageUrl)
    Box(modifier, contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = skin.marketHashName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
        } else {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(
                    Brush.linearGradient(listOf(rarityColor(skin.rarity).copy(alpha = .16f), Panel2))
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(skin.weapon.take(8), color = rarityColor(skin.rarity), fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun networkBitmap(url: String?) = produceState<Bitmap?>(initialValue = null, key1 = url) {
    if (url == null) return@produceState
    value = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 7_000
                readTimeout = 7_000
                setRequestProperty("User-Agent", "Mozilla/5.0 CaseForge/0.1 Android")
            }
            try {
                if (connection.responseCode in 200..299) BitmapFactory.decodeStream(connection.inputStream) else null
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }
}

private fun rarityColor(rarity: Rarity): Color = when (rarity) {
    Rarity.MIL_SPEC -> Color(0xFF4B69FF)
    Rarity.RESTRICTED -> Color(0xFF8847FF)
    Rarity.CLASSIFIED -> Color(0xFFD32CE6)
    Rarity.COVERT -> Color(0xFFEB4B4B)
    Rarity.EXTRAORDINARY -> Color(0xFFFFC857)
}

